#ifndef H_IMG_PROCESS_
#define H_IMG_PROCESS_
void get_img_data(char* img_name, double *f);
#endif // !H_IMG_PROCESS_
