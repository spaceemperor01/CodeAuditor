#pragma once
#ifndef H_INITIALIZE_
void initialize();
double make_rand();
#endif // !H_INITIALIZE_
