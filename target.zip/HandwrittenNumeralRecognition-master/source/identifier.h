#pragma once
#ifndef H_IDENTIFIER_
#define H_IDENTIFIER_
int identifier(train_data test_data, int if_put);
#endif // H_IDENTIFIER_
